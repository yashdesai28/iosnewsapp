//
//  APICaller.swift
//  self086
//
//  Created by bmiit on 04/03/24.
//

import Foundation
import UIKit

final class APICaller{
    static let shared = APICaller();
    
    struct Constants {
       static let topHeadlinedsURL = URL(string:"https://newsapi.org/v2/everything?q=tesla&from=2024-02-04&sortBy=publishedAt&apiKey=d14463e7c11a4583bd5e15bde56f3ac4")
    }
    
    private init(){
        
    }
    // resault have 2 parameter
    public func getTopStories(completion:@escaping (Result<[String],Error>)->Void){
        guard let url = Constants.topHeadlinedsURL else {
            return
        }
        let task = URLSession.shared.dataTask(with: url){ data, _, error in
            
            if let error = error{
                completion(.failure(error))
            }
            else if let data = data
            {
                
                do {
                    let result = try JSONDecoder().decode(APIResponse.self, from: data)
                    print("Articles : \(result.articles.count)")
                }
                catch{
                    completion(.failure(error))
                }
            }
                
        }
        task.resume();
    }
    
}

// models

struct APIResponse : Codable {
    
    let articles: [Article]
}

struct Article :Codable {
//    let source : Source
  //  let title : String
//    let description : String
//    let url : String
//    let urlToImage : String
//    let publishedAt : String
}

struct Source : Codable {
//    let name : String
    
    
}
