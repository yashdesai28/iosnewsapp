//
//  ViewController.swift
//  self086
//
//  Created by bmiit on 04/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    title = "News"
        view.backgroundColor =  .systemBackground
    }


}

